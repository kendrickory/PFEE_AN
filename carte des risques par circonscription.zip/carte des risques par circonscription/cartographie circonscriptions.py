from pathlib import Path
import geopandas as panda
import folium
import random
from folium.plugins import Geocoder
from folium.features import  GeoJsonPopup

BASE_DIR = Path(__file__).resolve().parent


all_circo = panda.read_file(BASE_DIR / "circonscriptions_france_complete.geojson")

m = folium.Map(location=[46.6, 2.4], zoom_start=6, tiles=None
               , max_bounds=True,)

folium.TileLayer(
    'CartoDB positron',
    name='Fond de carte',
    no_wrap=True,      
).add_to(m)
all_circo["risque_institutionel"] = [random.randint(0, 100) for _ in range(len(all_circo))]

all_circo["risque_des_ressources"] = [random.randint(0, 100) for _ in range(len(all_circo))]
all_circo["risque_infrastructurel"] = [random.randint(0, 100) for _ in range(len(all_circo))]


  


all_circo["risque_total"] = (
    0.3 * (all_circo["risque_institutionel"] / all_circo["risque_institutionel"].max()) +
    0.3 * (all_circo["risque_des_ressources"] / all_circo["risque_des_ressources"].max()) +
    0.3 * (all_circo["risque_infrastructurel"] / all_circo["risque_infrastructurel"].max())
)


all_circo["risque_total"] = 100 * (all_circo["risque_total"] - all_circo["risque_total"].min()) / (all_circo["risque_total"].max() - all_circo["risque_total"].min())


geojson_layer= folium.GeoJson(
    all_circo,
    no_wrap = True,
    name="Circonscriptions législatives 2022",
    
    highlight_function=lambda feature: {
        "fillColor": "#ffff00",  
        "color": "white",
        "weight": 3,
        "fillOpacity": 0.6,
    },
    
    style_function=lambda x: {"fillOpacity": 0.01, "color": "black", "weight": 0.7},
    popup=folium.GeoJsonPopup(
        fields=["nomDepartement","nomCirconscription"],
        aliases=["Département","Circonscription :"],
        localize=True,
       labels=True,
       style="background-color: white; font-size: 12px;"
    )
).add_to(m)



def get_color_instit(value):
    if value is None:
        return "#cccccc"
    elif value < 20:
        return "#deebf7"
    elif value < 40:
        return "#9ecae1"
    elif value < 60:
        return "#6baed6"
    elif value < 80:
        return "#3182bd"
    else:
        return "#08519c"

def get_color_ress(value):
    if value is None:
        return "#cccccc"
    elif value < 20:
        return "#edf8e9"
    elif value < 40:
        return "#bae4b3"
    elif value < 60:
        return "#74c476"
    elif value < 80:
        return "#31a354"
    else:
        return "#006d2c"

def get_color_infra(value):
    if value is None:
        return "#cccccc"
    elif value < 20:
        return "#feedde"
    elif value < 40:
        return "#fdd0a2"
    elif value < 60:
        return "#fdae6b"
    elif value < 80:
        return "#fd8d3c"
    else:
        return "#e6550d"

def get_color_total(value):
    if value is None:
        return "#cccccc"
    elif value < 20:
        return "#fff7bc"
    elif value < 40:
        return "#fec44f"
    elif value < 60:
        return "#fe9929"
    elif value < 80:
        return "#d95f0e"
    else:
        return "#993404"

# --- Style et surbrillance ---

def make_style_function(risk_col, color_func):
    def style_function(feature):
        value = feature["properties"].get(risk_col)
        return {
            "fillColor": color_func(value),
            "color": "black",
            "weight": 0.7,
            "fillOpacity": 0.7,
        }
    return style_function

highlight_style = lambda feat: {
    "weight": 3,
    "color": "white",
    "fillOpacity": 0.8,
}

# --- Fonction pour créer les couches ---

def make_layer(name, risk_col, color_func, popup_fields, popup_aliases):
    if name!="Risque combiné":
        return folium.GeoJson(
            data=all_circo.__geo_interface__,
            name=name,
            style_function=make_style_function(risk_col, color_func),
            highlight_function=highlight_style,
            show=False,
            popup=GeoJsonPopup(
                fields=popup_fields,
                aliases=popup_aliases,
                localize=True,
                labels=True,
                style="background-color: white; font-size: 12px;"
            ),
    
        )
    else:
         return folium.GeoJson(
            data=all_circo.__geo_interface__,
            name=name,
            style_function=make_style_function(risk_col, color_func),
            highlight_function=highlight_style,

            popup=folium.GeoJsonPopup(
                fields=["nomDepartement","nomCirconscription", "risque_institutionel", 
                "risque_des_ressources", "risque_infrastructurel"],
                aliases=["Département","Circonscription :", 
                 "Risque institutionel :", "Risque des ressources :", "Risque infrastructurel :"],
                localize=True,
                labels=True,
                style="background-color: white; font-size: 12px;"
            )
    
        )

# --- Création des couches personnalisées ---

layer_instit = make_layer(
    "Risque institutionnel",
    "risque_institutionel",
    get_color_instit,
    ["nomDepartement", "nomCirconscription", "risque_institutionel"],
    ["Département :", "Circonscription :", "Risque institutionnel :"]
)

layer_ress = make_layer(
    "Risque des ressources",
    "risque_des_ressources",
    get_color_ress,
    ["nomDepartement", "nomCirconscription", "risque_des_ressources"],
    ["Département :", "Circonscription :", "Risque des ressources :"]
)

layer_infra = make_layer(
    "Risque infrastructurel",
    "risque_infrastructurel",
    get_color_infra,
    ["nomDepartement", "nomCirconscription", "risque_infrastructurel"],
    ["Département :", "Circonscription :", "Risque infrastructurel :"]
)

layer_total = make_layer(
    "Risque combiné",
    "risque_total",
    get_color_total,
    ["nomDepartement", "nomCirconscription", "risque_total"],
    ["Département :", "Circonscription :", "Risque combiné :"]
)

# --- Ajout à la carte ---

layer_total.add_to(m)  # affichée par défaut
layer_instit.add_to(m)
layer_ress.add_to(m)
layer_infra.add_to(m)

folium.LayerControl(collapsed=False).add_to(m)

Geocoder(geocoder_options={'countrycodes': 'fr'},  
    collapsed=False,                        
    add_marker=True  ).add_to(m)



m.save(BASE_DIR / "carte_france_circonscriptions.html")
